# Blueprint Memory Lab · Demo

这是基于 UI UX Pro Max **Minimalism & Swiss Style** 制作的全新界面演示分支。

`main` 分支和现有 GitHub Pages 保持不变。

![桌面版预览](screenshots/desktop.png)

![手机版预览](screenshots/android-app.png)

## 分支内容

- 重构后的响应式网页版
- 573 条 UE5 Blueprint 中英词条
- 艾宾浩斯式复习与拆词、联想记忆
- Epic 官方教程多层筛选
- 有道发音和 Android 原生语音回退
- 独立 Android APK 演示包

## 本地预览

下载分支后直接打开 `index.html`。

## Android APK

- **直接下载 APK**：[Blueprint-Study-Redesign-v1.1.0.apk](https://github.com/hyx3251591466/ue5-blueprint-memory-lab/releases/download/demo-v1.1.0/Blueprint-Study-Redesign-v1.1.0.apk)
- **网页离线 ZIP**：[Blueprint-Study-Redesign-Web-v1.1.0.zip](https://github.com/hyx3251591466/ue5-blueprint-memory-lab/releases/download/demo-v1.1.0/Blueprint-Study-Redesign-Web-v1.1.0.zip)
- **Demo Release 页面**：[查看所有演示版下载](https://github.com/hyx3251591466/ue5-blueprint-memory-lab/releases/tag/demo-v1.1.0)

- 独立包名：`com.blueprintmemorylab.redesign`
- 可与正式版同时安装
- 支持 Android 6.0 及以上
- APK SHA-256：`BD81A92A2CF7F343DB70F9DA50C3B1AFF4D9A07953B61DC13E06CDB74F2DA5C1`

## 说明

此分支用于界面评审，暂不自动替换正式 GitHub Pages。确认最终风格后，再决定是否合并到 `main`。
